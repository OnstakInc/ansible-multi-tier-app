<?php

require( dirname( __FILE__ ) . '/wp-config.php' );

try {

    $redis = new Redis();

    $redis->connect(REDIS_HOST, REDIS_PORT);

    $my_data = array('first_name' => 'John', 'last_name' => 'Doe', 'age' => 25, 'address' => 'California, USA.');

    $redis->set('user_details', json_encode($my_data));

    $response = $redis->get('user_details');

    $result = json_decode($response);

    echo var_dump($result);

} catch (Exception $ex) {
    echo $ex;
}

?>
